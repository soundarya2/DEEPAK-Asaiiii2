var config = {
	apiKey : "AIzaSyCnxwgtcXPrsr_-fbgpoPT2cV6Ll5h8xbg",
	authDomain : "iplscorerapp.firebaseio.com",
	databaseURL : "https://iplscorerapp.firebaseio.com",
	projectId : "iplscorerapp",
	storageBucket : "iplscorerapp.appspot.com",
	messagingSenderId : "806526944961"
};
firebase.initializeApp(config);

var reference = firebase.database().ref('schema/match_schema');
reference
		.on(
				'value',
				function(snapshot) {

					$
							.ajax({
								url : '/bin/ipl-scorer/scorerapp',
								data : {

									testPostData : "hello"

								},
								error : function() {
									console.log("error");
								},

								success : function(data) {
									var a = JSON.parse(data);
									console.log(a);

									document.getElementById("left_avatar").src = "";
									document.getElementById("right_avatar").src = "";

									if ("current_over" in a) {
										var split = a.current_over.split(".");
										console.log(split);
										if (1 < split.length) {
											if (split[1] == "6") {
												console.log(split[0]);
												a.current_over = (parseInt(split[0]) + 1)
														.toString();
											}
										}
									}

									console.log(a.current_over);
									if ("first_innings_total" in a) {
										document
												.getElementById("first_innings_total").innerHTML = a.first_innings_total;
									}
									if ("first_innings_wickets" in a) {
										document
												.getElementById("first_innings_wickets").innerHTML = a.first_innings_wickets;
									}

									if ("current_over" in a) {
										document
												.getElementById("first_current_over").innerHTML = a.current_over;
										document.getElementById("over_count").innerHTML = a.current_over;
									}
									if ("total_overs" in a) {
										document
												.getElementById("first_total_over").innerHTML = a.total_overs;
									}

									if ("current_innings" in a) {

										if (a.current_innings == "FIRST") {

											if ("current_bowling_team" in a) {
												document
														.getElementById("current_bowling_team").innerHTML = a.current_bowling_team;
											}

											if ("current_batting_team" in a) {
												document
														.getElementById("current_batting_team").innerHTML = a.current_batting_team;
											}

											if ("current_batsman_avatar" in a) {
												document
														.getElementById("left_avatar").src = "http://54.175.213.131:3000/"
														+ a.current_batsman_avatar;

											}

											if ("current_bowler_avatar" in a) {
												document
														.getElementById("right_avatar").src = "http://54.175.213.131:3000/"
														+ a.current_bowler_avatar;

											}

											if ("current_batsman_name" in a) {

												var res = a.current_batsman_name
														.split(" ");
												console.log(res[1][0]);

												if (1 < res.length) {
													if (res[1][0] != undefined) {
														document
																.getElementById("left_name").innerHTML = res[0]
																+ " "
																+ res[1][0];
													} else {
														document
																.getElementById("left_name").innerHTML = res[0];
													}
												}
                                                else {
														document
																.getElementById("left_name").innerHTML = res[0];
													}

											}

											if ("current_batsman_runs" in a) {
												document
														.getElementById("left_stats").innerHTML = a.current_batsman_runs;
												if ("current_batsman_balls" in a) {
													document
															.getElementById("left_stats").innerHTML = a.current_batsman_runs
															+ "("
															+ a.current_batsman_balls
															+ ")";
												}
											}
											if ("current_batsman_name" in a) {
												if (a.current_batsman_name == "-") {
													document
															.getElementById("left_name").innerHTML = " ";
													document
															.getElementById("left_stats").innerHTML = " ";
												}

											}

											if ("current_bowler_name" in a) {

												var res = a.current_bowler_name
														.split(" ");

												if (1 < res.length) {
													if (res[1][0] != undefined) {
														document
																.getElementById("right_name").innerHTML = res[0]
																+ " "
																+ res[1][0];
													} else {
														document
																.getElementById("right_name").innerHTML = res[0];
													}
												}else {
														document
																.getElementById("right_name").innerHTML = res[0];
													}

											}
											if ("current_bowler_runs" in a) {
												document
														.getElementById("right_stats").innerHTML = a.current_bowler_runs;
												if ("current_bowler_wickets" in a) {
													document
															.getElementById("right_stats").innerHTML = a.current_bowler_runs
															+ "-"
															+ a.current_bowler_wickets;
												}
											}
											if ("current_bowler_name" in a) {
												if (a.current_bowler_name == "-") {
													document
															.getElementById("right_name").innerHTML = " ";
													document
															.getElementById("right_stats").innerHTML = " ";
												}

											}

											document
													.getElementById("second_innings_total").innerHTML = "";
											document
													.getElementById("second_innings_wickets").innerHTML = "";
											document
													.getElementById("second_current_over").innerHTML = "";
											document
													.getElementById("second_total_over").innerHTML = "";

										}

										else {

											if ("current_over" in a) {
												document
														.getElementById("first_current_over").innerHTML = a.total_overs;

											}

											if ("current_bowling_team" in a) {
												document
														.getElementById("current_bowling_team").innerHTML = a.current_batting_team;
											}

											if ("current_batting_team" in a) {
												document
														.getElementById("current_batting_team").innerHTML = a.current_bowling_team;
											}

											if ("current_bowler_avatar" in a) {
												document
														.getElementById("left_avatar").src = "http://54.175.213.131:3000/"
														+ a.current_bowler_avatar;

											}

											if ("current_batsman_avatar" in a) {
												document
														.getElementById("right_avatar").src = "http://54.175.213.131:3000/"
														+ a.current_batsman_avatar;

											}

											if ("current_bowler_name" in a) {
												var res = a.current_bowler_name
														.split(" ");

												if (1 < res.length) {
													if (res[1][0] != undefined) {
														document
																.getElementById("left_name").innerHTML = res[0]
																+ " "
																+ res[1][0];
													} else {
														document
																.getElementById("left_name").innerHTML = res[0];
													}
												}
                                                else {
														document
																.getElementById("left_name").innerHTML = res[0];
													}

											}
											if ("current_bowler_runs" in a) {
												document
														.getElementById("left_stats").innerHTML = a.current_bowler_runs;
												if ("current_bowler_wickets" in a) {
													document
															.getElementById("left_stats").innerHTML = a.current_bowler_runs
															+ "-"
															+ a.current_bowler_wickets;
												}
											}
											if ("current_bowler_name" in a) {
												if (a.current_bowler_name == "-") {
													document
															.getElementById("left_name").innerHTML = " ";
													document
															.getElementById("left_stats").innerHTML = " ";
												}

											}

											if ("current_batsman_name" in a) {

												var res = a.current_batsman_name
														.split(" ");
												console.log(res);

												if (1 < res.length) {
													if (res[1][0] != undefined) {
														document
																.getElementById("right_name").innerHTML = res[0]
																+ " "
																+ res[1][0];
													} else {
														document
																.getElementById("right_name").innerHTML = res[0];
													}
												}
                                                else {
														document
																.getElementById("right_name").innerHTML = res[0];
													}

											}
											if ("current_batsman_runs" in a) {
												document
														.getElementById("right_stats").innerHTML = a.current_batsman_runs;
												if ("current_batsman_balls" in a) {
													document
															.getElementById("right_stats").innerHTML = a.current_batsman_runs
															+ "("
															+ a.current_batsman_balls
															+ ")";
												}
											}
											if ("current_batsman_name" in a) {
												if (a.current_batsman_name == "-") {
													document
															.getElementById("right_name").innerHTML = " ";
													document
															.getElementById("right_stats").innerHTML = " ";
												}

											}

											if ("second_innings_total" in a) {
												document
														.getElementById("second_innings_total").innerHTML = a.second_innings_total;
											}
											if ("second_innings_wickets" in a) {
												document
														.getElementById("second_innings_wickets").innerHTML = a.second_innings_wickets;
											}

											if ("current_over" in a) {
												document
														.getElementById("second_current_over").innerHTML = a.current_over;
												document
														.getElementById("over_count").innerHTML = a.current_over;
											}
											if ("total_overs" in a) {
												document
														.getElementById("second_total_over").innerHTML = a.total_overs;
											}
											if ("is_match_over" in a) {
												if (a.is_match_over == "TRUE") {

													document
															.getElementById("second_current_over").innerHTML = a.total_overs;
												}
											}

										}
										if ("notifications" in a) {
											document
													.getElementById("notifications").innerHTML = a.notifications;

										}
										console.log(a);
										document.getElementById("replace").innerHTML = "";
										var d = document
												.createDocumentFragment();
										for (var i = 0; i < 50; i++) {

											if ("ball_" + String(i) in a) {

												var temp = "ball_" + String(i);
												var p = document
														.createElement("li");

												var para = document
														.createElement("span");

												var pnode = document
														.createTextNode(a[""
																+ temp + ""]);
												if (a["" + temp + ""] == "4") {
													p.setAttribute("class",
															"ball four");
												} else if (a["" + temp + ""] == "6") {
													p.setAttribute("class",
															"ball six");
												} else if (a["" + temp + ""] == "1"
														|| a["" + temp + ""] == "2"
														|| a["" + temp + ""] == "3"
														|| a["" + temp + ""] == "0"
														|| a["" + temp + ""] == ".") {
													p.setAttribute("class",
															"ball");
												} else {
													p.setAttribute("class",
															"ball extra");

												}

												para.appendChild(pnode);

												p.appendChild(para);
												d.appendChild(p);

											}
										}

										var element = document
												.getElementById("replace");
										element.appendChild(d);

									}

								},
								type : 'POST'
							});

				});
